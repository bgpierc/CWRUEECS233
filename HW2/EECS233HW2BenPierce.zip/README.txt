Benjamin Pierce -bgp12@case.edu

HW2- The report, in .tex and .pdf
Permutation.java- my code for the permutation
PermutationTest.java- my code for Parts C & D
PuzzleSolver3.java- my code for Part B; uses Permutation.java to solve puzzle

Note: resubmit is due to me using old version of the code, which caused errors in the runtimes.