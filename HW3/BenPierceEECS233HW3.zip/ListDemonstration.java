// Chris Fietkiewicz (cxf47) Demonstrates IntLinkedBag class.
public class ListDemonstration {
    public static void main(String[] args) {
        IntLinkedBag b = new IntLinkedBag();
		int N = 7;
		for (int i = 0; i < N; i++) {
			b.add(i);
		}
    }
}
