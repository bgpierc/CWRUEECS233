Ben Pierce (bgp12)

Files inculded:
Problem1,Problem2,Problem3- Individual solutions to the problems.
Graph- This file does everything that the previous files do.  See comment in Graph.java
Grapher- The Grapher.java file provided, imported in Graph.java
Over1K,Under1K- Image files of the graphs.
EECS233BenPierce- The report. In both .tex and .pdf.


