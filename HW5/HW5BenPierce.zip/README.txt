The report is HW5ReportBenPierce.pdf and also the .tex file is included
The code for Question 1 is Question1.java
The code for Question 2 is Fractal3.java
The code for Question 3 is Grid.java and RecursiveGrid.java