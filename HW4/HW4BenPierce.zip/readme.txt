Code for question 1 is in balancedParens.java
Code for question 3 is the modified files given 
Code for question 6 is in Postfix.java